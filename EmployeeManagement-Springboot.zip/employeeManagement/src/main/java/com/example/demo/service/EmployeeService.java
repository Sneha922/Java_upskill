package com.example.demo.service;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;

@Service
public class EmployeeService {
	@Autowired
	private Employee employee;
	
	Scanner sc =  new Scanner(System.in);
	
	public void createEmployee() {
		
		String name;
		while(true) {
			System.out.println("Enter Name : ");
			name = sc.nextLine();
			if(name.trim().split("\\s+").length <=2) {
				employee.setName(name);
				break;
			}else {
				System.out.println("Name should contain only two spaces");
			}
		}
		while(true) {
			System.out.println("Enter Age : ");
			int age = sc.nextInt();
			sc.nextLine();
			if(age>=20 && age<=60) {
				employee.setAge(age);
				break;
			}
			System.out.println("Invalid Age!");
		}
		System.out.println("Enter Designation : ");
		String d = sc.next().toUpperCase();
		switch(d) {
		case "PROGRAMMER":
			employee.setDesignation("Programmer");
			employee.setSalary(20000);
			break;
		case "MANAGER":
			employee.setDesignation("Manager");
			employee.setSalary(25000);
			break;
		case "TESTER":
			employee.setDesignation("Tester");
			employee.setSalary(15000);
			break;
		default:
			System.out.println("Invalid designation!");
			return;
		}
		System.out.println("Employee created successfully");
		sc.nextLine();
	}
	
	public void displayEmployee() {
		employee.display();
	}
	
	public void raiseSalary() {
		System.out.println("Enter Percentage (1-10): ");
		int percent = sc.nextInt();
		sc.nextLine();
		if(percent<1 || percent>10) {
			System.out.println("Invalid Percentage!");
			return;
		}
		
		double newSalary = employee.getSalary()+(employee.getSalary()*percent/100);
		employee.setSalary(newSalary);
		System.out.println("Salary Updated Successfully!!");
		System.out.println("New salary: "+newSalary);
	}
}
