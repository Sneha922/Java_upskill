package com.example.demo;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.service.EmployeeService;

@SpringBootApplication
public class EmployeeManagementApplication implements CommandLineRunner{
	
	@Autowired
	private EmployeeService service;
	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementApplication.class, args);
	}
	
	@Override
	public void run(String... args) {
		Scanner sc = new Scanner(System.in);
		int choice;
		
		do {
			System.out.println("Main menu");
			System.out.println("1) Create \n2) Display \n3) Raise Salary \n4) Exit\nEnter Choice: ");
			choice = sc.nextInt();
			sc.nextLine();
			switch(choice) {
			case 1:
				service.createEmployee();
				break;
			case 2:
				service.displayEmployee();
				break;
			case 3:
				service.raiseSalary();
				break;
			case 4:
				System.out.println("Thank you for using the application");
				break;
			default:
				System.out.println("Invalid Choice");
			}
		}while(choice != 4);
	}

}
