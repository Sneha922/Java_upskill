package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    // CREATE
    @PostMapping("/create")
    public Employee createEmployee(@RequestBody Employee emp) {
        return service.create(emp);
    }

    // DISPLAY
    @GetMapping("/{id}")
    public Employee displayEmployee(@PathVariable int id) {
        return service.getEmployee(id);
    }

    // RAISE SALARY
    @PutMapping("/raise/{id}/{percent}")
    public Employee raiseSalary(
            @PathVariable int id,
            @PathVariable int percent) {
        return service.raiseSalary(id, percent);
    }
    
    //EXIT
    @GetMapping("/exit")
    public String exit() {
    	return "Thank you for using the application";
    }
}
