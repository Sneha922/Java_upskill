package assessment;

import java.sql.*;
import java.util.*;

class DB {
    private static Connection con;

    public static Connection getConnection() {
        if (con != null) return con;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost.3306/EmployeeApp",  // Change if needed
                    "root",  // your username
                    "Root123$"   // your password
            );
            System.out.println("Connected to MySql DB!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
}

class Employee {
    String name;
    int age;
    String designation;
    double salary;
}

public class EmployeeApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Connection con = DB.getConnection();

        while (true) {
            System.out.println("\n1) Create");
            System.out.println("2) Display Last 10");
            System.out.println("3) Raise Salary");
            System.out.println("4) Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {

                case 1:
                    Employee emp = new Employee();

                    // Name
                    while (true) {
                        System.out.print("Enter Name (2 spaces): ");
                        String n = sc.nextLine();
                        if (n.chars().filter(c -> c == ' ').count() <= 2) {
                            emp.name = n;
                            break;
                        }
                        System.out.println("Name must contain exactly TWO spaces.");
                    }

                    // Age
                    while (true) {
                        System.out.print("Enter Age (20–60): ");
                        int a = sc.nextInt();
                        sc.nextLine();
                        if (a >= 20 && a <= 60) {
                            emp.age = a;
                            break;
                        }
                        System.out.println("Invalid age! Try again.");
                    }

                    // Designation
                    System.out.print("Enter Designation (P20/M25/T15): ");
                    emp.designation = sc.nextLine();

                    switch (emp.designation.toUpperCase()) {
                        case "PROGRAMMER": emp.salary = 20000; break;
                        case "MANAGER": emp.salary = 25000; break;
                        case "TESTER": emp.salary = 15000; break;
                    }

                    try {
                        PreparedStatement pst = con.prepareStatement(
                                "INSERT INTO employee(name, age, designation, salary) VALUES (?,?,?,?)");
                        pst.setString(1, emp.name);
                        pst.setInt(2, emp.age);
                        pst.setString(3, emp.designation);
                        pst.setDouble(4, emp.salary);
                        pst.executeUpdate();

                        System.out.println("Employee inserted successfully!");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case 2:
                    System.out.println("\n--- LAST 10 ENTRIES ---");

                    try {
                        PreparedStatement pst = con.prepareStatement(
                                "SELECT * FROM (SELECT * FROM employee ORDER BY id DESC) WHERE ROWNUM <= 10"
                        );

                        ResultSet rs = pst.executeQuery();

                        while (rs.next()) {
                            System.out.println(
                                    rs.getInt("id") + " | " +
                                    rs.getString("name") + " | " +
                                    rs.getInt("age") + " | " +
                                    rs.getString("designation") + " | " +
                                    rs.getDouble("salary")
                            );
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case 3:
                    System.out.print("Enter employee name: ");
                    String nm = sc.nextLine();

                    System.out.print("Enter raise percentage (1–10): ");
                    int p = sc.nextInt();
                    sc.nextLine();

                    try {
                        PreparedStatement pst = con.prepareStatement(
                                "UPDATE employee SET salary = salary + (salary * ? / 100) WHERE name = ?"
                        );
                        pst.setInt(1, p);
                        pst.setString(2, nm);
                        int updated = pst.executeUpdate();

                        if (updated > 0)
                            System.out.println("Salary updated!");
                        else
                            System.out.println("Employee not found!");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case 4:
                    System.out.println("Thank you for using the application!");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
