create database EmployeeApp;
use EmployeeApp;
create table employee(id Int auto_increment primary key,
name varchar(100),
age Int,
designation varchar(100),
salary double);