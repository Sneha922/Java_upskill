/**
 * 
 */
/**
 * 
 */
module Assessment {
	requires java.sql;
}