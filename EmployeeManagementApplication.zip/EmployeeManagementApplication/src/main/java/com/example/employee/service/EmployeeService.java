package com.example.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.employee.model.Employee;
import com.example.employee.repository.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    public String saveEmployee(Employee emp,Model model) {
    	System.out.println(emp.getAge());
        // AGE VALIDATION
        if (emp.getAge() < 20 || emp.getAge() > 60) {
        	model.addAttribute("error","Age must be between 20 and 60");
            return "create";
        }

        // NAME VALIDATION (only 2 spaces allowed)
        long spaceCount = emp.getName().chars()
                             .filter(ch -> ch == ' ')
                             .count();

        if (spaceCount > 2) {
        	model.addAttribute("error","Name must contain exactly 2 spaces");
            return "create";
        }
        
        switch(emp.getDesignation().toUpperCase()) {
        case "PROGRAMMER":
        	emp.setDesignation("Programmer");
        	emp.setSalary(20000);
        	break;
        case "MANAGER":
        	emp.setDesignation("Manager");
        	emp.setSalary(25000);
        	break;
        case "TESTER":
        	emp.setDesignation("Tester");
        	emp.setSalary(15000);
        	break;
        default:
        	throw new RuntimeException("Invalid designation");
        }

        repo.save(emp);
        return "menu";
    }

    public String getAllEmployees(Model model) {
    	model.addAttribute("employees", repo.findAll());
        return "display";
    }
    
    public String getEmployee(int id,Model model) {
    	Employee emp = repo.findById(id).orElse(null);
    	if (emp == null) {
        	model.addAttribute("error","Employee not found");
            return "displaybyid";
        }
    	model.addAttribute("employee", emp);
    	return "displaybyid";
    }

    public String raiseSalary(int id, int percent,Model model) {
        Employee emp = repo.findById(id).orElse(null);

        if (emp == null) {
        	model.addAttribute("error","Employee not found");
            return "raise";
        }
        if(percent<1||percent>10) {
        	model.addAttribute("error","Percent should between 1 and 10");
            return "raise";
        }
        double salary = emp.getSalary() + (emp.getSalary() * percent / 100);
        emp.setSalary(salary);
        repo.save(emp);

        return "menu";
    }
}
