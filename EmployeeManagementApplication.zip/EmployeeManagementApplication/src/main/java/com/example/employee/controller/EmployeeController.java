package com.example.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.employee.model.Employee;
import com.example.employee.repository.EmployeeRepository;
import com.example.employee.service.EmployeeService;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService service;
    @GetMapping("/")
    public String home() {
        return "index";
    }
    @GetMapping("/menu")
    public String menu() {
        return "index";
    }

    @GetMapping("/create")
    public String createPage() {
        return "create";
    }

    @PostMapping("/create")
    public String createEmployee(Employee emp,Model model) {
    	return service.saveEmployee(emp, model);
    }

    @GetMapping("/display")
    public String display(Model model) {
        return service.getAllEmployees(model);
    }
    @GetMapping("/displaybyid")
    public String displayEmployee(@RequestParam int id,Model model) {
        return service.getEmployee(id,model);
    }

    @GetMapping("/raise")
    public String raisePage() {
        return "raise";
    }

    @PostMapping("/raise")
    public String raiseSalary(@RequestParam int id,@RequestParam int percent,Model model) {
        return service.raiseSalary(id, percent,model);
    }
    @GetMapping("/exit")
    public String exit() {
    	return "exit";
    }
}
